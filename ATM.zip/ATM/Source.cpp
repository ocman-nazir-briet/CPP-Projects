/* Developed by Ocman Nazir Briet
* University of Central Punjab. Lahore Pakistan
* This program is consist of working of an ATM machine
* use the AC number and Password given below to access Account
*/
// AC		Password
/* 27531	1234
* 27532		2234
* 27533		3234
* 27534		4234
* 27535		5234
* 27536		6234
* 27537		7234
*/

#include<iostream>
#include<fstream>
#include<istream>
using namespace std;

void mainbalance();
void DepositMoney();
void TransferMoney();
void WithDraw();
void BalanceInquiry();
void account();
void Pin();

int deposit = 0;
int AC = 0;
int password = 0;

int main()
{
	cout << endl << "		  Welcome to Bank of Pakistan" << endl;
	cout << endl;
	cout << "+----------------------------------------------------------------+" << endl;
	cout << "| 1.Deposit Money				2.Transfer Money |" << endl;
	cout << "|                                                                |" << endl;
	cout << "| 3.Withdraw Money				4.Balance Inquiry|" << endl;
	cout << "|                                                                |" << endl;
	cout << "| 5.Fast Cash					6.PIN Change     |" << endl;
	cout << "+----------------------------------------------------------------+" << endl;
	cout << "Enter Account Number:		";
	cin >> AC;
	cout << "Enter password:			";
	cin >> password;
	mainbalance();
	return 0;
}

void account()
{
	int choice = 100;
	while (choice != 0)
	{
		cout << "Enter Your Choice" << endl;
		cin >> choice;
		{
			if (choice == 1)
			{
				DepositMoney();
			}
			else if (choice == 2)
			{
				TransferMoney();
			}
			else if (choice == 3)
			{
				WithDraw();
			}
			else if (choice == 4)
			{
				BalanceInquiry();
			}
			else if (choice == 5)
			{

			}
			else if (choice == 6)
			{
				Pin();
			}
		}
	}
}
void mainbalance()
{
	if (AC == 27531 && password == 1234)
	{
		deposit = 1820;
		account();
	}
	else if (AC == 27532 && password == 2234)
	{
		deposit = 50500;
		account();
	}
	else if (AC == 27533 && password == 3234)
	{
		deposit = 155000;
		account();
	}
	else if (AC == 27534 && password == 4234)
	{
		deposit = 56900;
		account();
	}
	else if (AC == 27535 && password == 5234)
	{
		deposit = 36400;
		account();
	}
	else if (AC == 27536 && password == 6234)
	{
		deposit = 364570;
		account();
	}
	else if (AC == 27537 && password == 7234)
	{
		deposit = 365470;
		account();
	}
	else
	{
		cout << "Invalid AC Number or Password";
	}
}
void DepositMoney()
{
	int amount = 0;
	cout << "Enter Amount to Deposit:	";
	cin >> amount;
	deposit = deposit + amount;
	cout << "***Deposited Successfully***" << endl;
}
void TransferMoney()
{
	int amount = 0;
	cout << "Enter Amount to Transfer:	";
	while (amount != 500)
	{
		cin >> amount;
		if (amount != 500)
		{
			cout << "Invalid Amount" << endl;
		}
	}
	deposit = deposit - amount;
	cout << "***Amount Transferred Successfully***" << endl;
}

void WithDraw()
{
	int amount = 0;
	cout << "How Much Money you Want to Withdraw:	" << endl;
	if (deposit >= 520)
	{
		while (amount != 500)
		{
			cin >> amount;
			if (amount != 500)
			{
				cout << "Invalid Amount" << endl;
			}
		}
		
		deposit = deposit - amount;
		deposit = deposit - 20;
		cout << "***Withdraw Successfully***" << endl;
	}
	else if (deposit < 520)
	{
		cout << "Insufficient Balance " << deposit << endl;
	}
}
void BalanceInquiry()
{
	cout << "Your Current Balance is :	" << deposit << endl;;
}
void Pin()
{
	int pass = 0;
	int newpass = 0;
	cout << "Enter Old Password:		";
	cin >> pass;
	if (pass == password)
	{
		cout << "Enter New Password:		";
		cin >> newpass;
		password = newpass;
	}
	else
	{
		cout << "Wrong Old Password" << endl;
	}
}