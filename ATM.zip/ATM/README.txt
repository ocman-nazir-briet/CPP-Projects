/* Developed by Ocman Nazir Briet
* University of Central Punjab. Lahore Pakistan
* This program is consist of working of an ATM machine
* use the AC number and Password given below to access Account
*/
// AC		Password
/* 27531	1234
* 27532		2234
* 27533		3234
* 27534		4234
* 27535		5234
* 27536		6234
* 27537		7234
*/
