#include<iostream>
#include<fstream>
#include<istream>
using namespace std;

void menu(int);
void Pakistani();
void Indian();
void Chinese();
void Russian();
void Bill();

float bill = 0; int biryani = 0; int karahi = 0; int nihari = 0; int pulao = 0; int salad = 0;						//Pakistani
int doosa = 0; int momo = 0; int appum = 0; int pakora = 0;															//Indian
int manchurian = 0; int friedChicken = 0; int chickenChilli = 0; int chowmein = 0; int chineseSalad = 0;			//Chinese
int russianSalad = 0; int pirozhki = 0; int borscht = 0; int syrniki = 0; int okroshka = 0;							//Russian

int main()
{
	int choice = 100;
	cout << "					     Welcome to " << endl;
	cout << "						the" << endl;
	cout << "					__________________" << endl;
	cout << "					Royal Briets Hotel " << endl;
	cout << "					__________________ " << endl;
	menu(choice);
	Bill();
	return 0;
}

void menu(int choice)
{
	cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "|					***Menu is Below***						|" << endl;
	cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "|					Press 1 for Pakistai food					|" << endl;
	cout << "|					Press 2 for Indian food						|" << endl;
	cout << "|					Press 3 for Chinese food					|" << endl;
	cout << "|					Press 4 for Russian food					|" << endl;
	cout << "|					Press 0 for *Nothing*						|" << endl;
	cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;

	while (choice != 0)
	{
		cout << "What Would you like to order Sir/Ma'am !" << endl;
		cin >> choice;
		{

			if (choice == 1)
			{
				Pakistani();
			}
			else if (choice == 2)
			{
				Indian();
			}
			else if (choice == 3)
			{
				Chinese();
			}
			else if (choice == 4)
			{
				Russian();
			}
		}
	}

}
void Pakistani()
{
	int choice=100;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "				|   ***Which Pakistani Food Would you like to have***   |" << endl;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "				| Press 1 for Biryani.   PKR 320			|" << endl;
	cout << "				| Press 2 for Karahi.    PKR 1450			|" << endl;
	cout << "				| Press 3 for Nihari.	 PKR 570			|" << endl;
	cout << "				| Press 4 for Pulao.	 PKR 220			|" << endl;
	cout << "				| Press 5 for salad.	 PKR 70				|" << endl;
	cout << "				| Press 0 for *Nothing*					|" << endl;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;

	while (choice != 0)
	{
		cin >> choice;
		{
			if (choice == 1)
			{
				bill = bill + 320;
				cout << "Biryani Added" << endl;
				biryani = biryani + 1;
			}
			else if (choice == 2)
			{
				cout << "Karahi Added" << endl;
				bill = bill + 1450;
				karahi = karahi + 1;
			}
			else if (choice == 3)
			{
				cout << "Nihari Added" << endl;
				bill = bill + 570;
				nihari = nihari + 1;
			}
			else if (choice == 4)
			{
				cout << "Pulao Added" << endl;
				bill = bill + 220;
				pulao = pulao + 1;
			}
			else if (choice == 5)
			{
				cout << "Salad Added" << endl;
				bill = bill + 70;
				salad = salad + 1;
			}
		}
	}
}
void Indian()
{
	int choice = 100;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "				|    ***Which Indian Food Would you like to have***     |" << endl;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "				| Press 1 for Doosa.	 PKR 200			|" << endl;
	cout << "				| Press 2 for Momo. 	 PKR 450			|" << endl;
	cout << "				| Press 3 for Appum.	 PKR 700			|" << endl;
	cout << "				| Press 4 for Pakora.	 PKR 860			|" << endl;
	cout << "				| Press 0 for *Nothing*					|" << endl;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;

	while (choice != 0)
	{
		cin >> choice;
		{
			if (choice == 1)
			{
				bill = bill + 200;
				cout << "Doosa Added" << endl;
				doosa = doosa + 1;
			}
			else if (choice == 2)
			{
				cout << "Momo Added" << endl;
				bill = bill + 450;
				momo = momo + 1;
			}
			else if (choice == 3)
			{
				cout << "Appum Added" << endl;
				bill = bill + 700;
				appum = appum + 1;
			}
			else if (choice == 4)
			{
				cout << "Pakora Added" << endl;
				bill = bill + 800;
				pakora = pakora + 1;
			}
		}
	}
}
void Chinese()
{
	int choice = 100;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "				|    ***Which Chinese Food Would you like to have***    |" << endl;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "				| Press 1 for Chicken Manchurian.	 PKR 200	|" << endl;
	cout << "				| Press 2 for Fried Chicken.		 PKR 450	|" << endl;
	cout << "				| Press 3 for Chicken Chilli.		 PKR 700	|" << endl;
	cout << "				| Press 4 for Chow Mein.		 PKR 700	|" << endl;
	cout << "				| Press 5 for Chinese Salad.		 PKR 860	|" << endl;
	cout << "				| Press 0 for *Nothing*					|" << endl;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;

	while (choice != 0)
	{
		cin >> choice;
		{
			if (choice == 1)
			{
				bill = bill + 200;
				cout << "Chicken Manchurian Added" << endl;
				manchurian = manchurian + 1;
			}
			else if (choice == 2)
			{
				cout << "Fried Chicken Added" << endl;
				bill = bill + 450;
				friedChicken = friedChicken + 1;
			}
			else if (choice == 3)
			{
				cout << "Chicken Chilli Added" << endl;
				bill = bill + 700;
				chickenChilli = chickenChilli + 1;
			}
			else if (choice == 4)
			{
				cout << "Chow Mein Added" << endl;
				bill = bill + 800;
				chowmein = chowmein + 1;
			}
			else if (choice == 5)
			{
				cout << "Chinese Salad Added" << endl;
				bill = bill + 800;
				chineseSalad = chineseSalad + 1;
			}
		}
	}
}
void Russian()
{
	int choice = 100;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "				|    ***Which Russian Food Would you like to have***    |" << endl;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "				| Press 1 for Syrniki.		 PKR 320		|" << endl;
	cout << "				| Press 2 for Borscht.		 PKR 1450		|" << endl;
	cout << "				| Press 3 for Pirozhki.		 PKR 570		|" << endl;
	cout << "				| Press 4 for Okroshka.		 PKR 220		|" << endl;
	cout << "				| Press 5 for Russian Salad.	 PKR 70			|" << endl;
	cout << "				| Press 0 for *Nothing*					|" << endl;
	cout << "				+++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;

	while (choice != 0)
	{
		cin >> choice;
		{
			if (choice == 1)
			{
				bill = bill + 320;
				cout << "Syrniki Added" << endl;
				syrniki = syrniki + 1;
			}
			else if (choice == 2)
			{
				cout << "Borscht Added" << endl;
				bill = bill + 1450;
				borscht = borscht + 1;
			}
			else if (choice == 3)
			{
				cout << "Nihari Added" << endl;
				bill = bill + 570;
				pirozhki = pirozhki + 1;
			}
			else if (choice == 4)
			{
				cout << "Okroshka Added" << endl;
				bill = bill + 220;
				okroshka = okroshka + 1;
			}
			else if (choice == 5)
			{
				cout << "Russian Salad Added" << endl;
				bill = bill + 70;
				russianSalad = russianSalad + 1;
			}
		}
	}
}

void Bill()
{
	char name[50];
	char number[20];
	float tax;
	tax = (bill / 100) * 7;
	bill = bill + tax;
	if (bill != 0)
	{
		cout << "Please Enter Customer Name:	";
		cin.ignore();
		cin.get(name, 50);
		cout << "Enter Phone Number:		";
		cin.ignore();
		cin.get(number, 20);
	}
	
	cout << endl;
	if (bill != 0)
	{
		cout << "____________________________________________" << endl;
		cout << "|Name   :	" << name << endl;
		cout << "|Number :	" << number << endl;
		cout << "|-------------------------------------------" << endl;
	}

	if (biryani != 0)
	{
		cout << "| Biryani		= " << biryani << endl;
	}
	if (karahi != 0)
	{
		cout << "| Karahi		= " << karahi << endl;
	}
	if (nihari != 0)
	{

		cout << "| Nihari		= " << nihari << endl;
	}
	if (pulao != 0)
	{

		cout << "| Pulao			= " << pulao << endl;
	}
	if (salad != 0)
	{
		cout << "| Salad			= " << salad << endl;
	}
	if (doosa != 0)
	{
		cout << "| Doosa			= " << doosa << endl;
	}
	if (momo != 0)
	{
		cout << "| Momo			= " << momo << endl;
	}
	if (appum != 0)
	{
		cout << "| Appum			= " << appum << endl;
	}
	if (pakora != 0)
	{
		cout << "| Pakora		= " << pakora << endl;
	}
	if (manchurian != 0)
	{
		cout << "| Chicken Manchurian	= " << manchurian << endl;
	}
	if (friedChicken != 0)
	{
		cout << "| Fried Chicken		= " << friedChicken << endl;
	}
	if (chickenChilli != 0)
	{
		cout << "| Chicken Chilli	= " << chickenChilli << endl;
	}
	if (chowmein != 0)
	{
		cout << "| Chow Mein		= " << chowmein << endl;
	}
	if (chineseSalad != 0)
	{
		cout << "| Chinese salad		= " << chineseSalad << endl;
	}
	if (pirozhki != 0)
	{
		cout << "| Pirozhki		= " << pirozhki << endl;
	}
	if (borscht != 0)
	{
		cout << "| Borscht		= " << borscht << endl;
	}
	if (syrniki != 0)
	{
		cout << "| Syrniki		= " << syrniki << endl;
	}
	if (okroshka != 0)
	{
		cout << "| Okroshka		= " << okroshka << endl;
	}
	if (russianSalad != 0)
	{
		cout << "| Russian salad		= " << russianSalad << endl;
	}
	cout << "|___________________________________________" << endl ;
	cout << "|	  Tax on your Bill is : " << tax << endl;
	cout << "|	  Your Total Bill is : " << bill << endl;
	cout << "|	***Thanks for Visiting us***" <<endl;
	cout << "|___________________________________________" << endl;
}
